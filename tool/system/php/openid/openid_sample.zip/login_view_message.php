<HTML>
<HEAD>
<META http-equiv="Content-type" content="text/html; charset=shift_jis" />
<TITLE>���O�C��</TITLE>
<STYLE type="text/css">
* {
	font-size: 12px;
}
</STYLE>
</HEAD>
<BODY>

<?= $error_message ?>

</BODY>
</HTML>
